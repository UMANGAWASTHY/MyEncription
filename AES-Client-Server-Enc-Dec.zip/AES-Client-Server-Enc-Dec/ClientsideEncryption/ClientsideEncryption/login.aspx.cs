﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ClientsideEncryption
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                if (string.IsNullOrEmpty(HDusername.Value))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Enter Username');", true);
                }
                else if (string.IsNullOrEmpty(HDPassword.Value))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Enter Password !');", true);
                }
                else
                {
                    var username = AESEncrytDecry.DecryptStringAES(HDusername.Value);
                    var password = AESEncrytDecry.DecryptStringAES(HDPassword.Value);
                    var usernameTest = AESEncrytDecry.DecryptStringAESNew(HDEncryptUser.Value,"123456");

                    var sipherText = "db67c6df231b05fc0443b7970870c9bb0ae841ce885e6afa8e992a1f8e3ced14b6d2YuBdQS/TcIADEmL12z4yPSo3CgR5CDi87Df2S1YG7pOgAdqTwOSjrgqDHO5xL0v6hbQX6Aho01ha2ZNvkhCoa7P40qquI/8NwVk23N27Eltm78OJShmA9UkTqR+Ugf1BacvcbkwkQllkHGB4zQ==";
                    var authInformation = AESEncrytDecry.DecryptStringAESNew(sipherText, "1234567891011121");

                    if (username == "keyError" && password == "keyError")
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Not vaild login');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('login successfully');", true);
                    }
                }
            }
        }
    }
}